# Japan Lock-In V12 Native Android

This project packages the same `index.html` as the V12 web build and adds native Android capabilities:

- exact task reminders using `AlarmManager.setExactAndAllowWhileIdle`
- native notification channel with normal notification sound
- background voice reminder using a short foreground service + Android TextToSpeech
- voice test through the same native path as scheduled reminders
- notification/channel/TTS/battery/exact-alarm diagnostic shortcuts
- boot, package-replaced, time-change, timezone-change and exact-alarm-permission rescheduling
- existing location, handwriting, cloud sync and WebView bridge

## Realme reminder setup

On realme devices, also allow the app to run in the background. realme documents these settings under App battery management: allow foreground activity, background activity and auto launch; realme also recommends locking the app in recents for background reliability.

The V12 Settings screen provides direct shortcuts to app notification settings, the reminder channel, app/battery settings and Android Text-to-speech settings.

## APK

The source is a real Android Gradle project. This environment does not include the Android SDK/build-tools, so a binary APK cannot be compiled here. Open the project in Android Studio and build a signed APK.
