import { getStore } from '@netlify/blobs';
import { createHash } from 'node:crypto';

const STORE_NAME = 'japan-lockin-sync';
const STORE_REGION = 'us-east-2';
const MAX_CODE_LEN = 32;
const MAX_CHANGES = 250;
const MAX_ENTITY_BYTES = 700_000;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'no-store'
};

function response(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8' }
  });
}

function normalizeCode(value) {
  return String(value ?? '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function validCode(code) {
  return code.length >= 8 && code.length <= MAX_CODE_LEN;
}

function spaceId(code) {
  return createHash('sha256').update(code).digest('hex');
}

function encodedEntityKey(key) {
  return Buffer.from(String(key), 'utf8').toString('base64url');
}

function blobKey(space, key) {
  return `v1/${space}/${encodedEntityKey(key)}`;
}

function store() {
  return getStore({ name: STORE_NAME, region: STORE_REGION });
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

async function readEntity(st, key) {
  return st.get(key, { consistency: 'strong', type: 'json' });
}

export default async function handler(req) {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (req.method === 'GET') return response({ ok: true, service: 'japan-lockin-sync', version: 1 });
  if (req.method !== 'POST') return response({ ok: false, error: 'Method not allowed' }, 405);

  let body;
  try { body = await req.json(); } catch { return response({ ok: false, error: 'Invalid JSON body' }, 400); }

  const code = normalizeCode(body?.code);
  if (!validCode(code)) return response({ ok: false, error: 'Invalid sync code' }, 400);

  const action = body?.action;
  if (action !== 'pull' && action !== 'push') return response({ ok: false, error: 'Unsupported sync action' }, 400);

  const st = store();
  const prefix = `v1/${spaceId(code)}/`;

  if (action === 'pull') {
    const listing = await st.list({ prefix });
    const entities = [];
    for (const item of listing.blobs || []) {
      const data = await readEntity(st, item.key);
      if (!data || typeof data.key !== 'string') continue;
      entities.push({
        key: data.key,
        updatedAt: Number(data.updatedAt) || 0,
        deleted: !!data.deleted,
        value: data.deleted ? null : data.value
      });
    }
    entities.sort((a, b) => a.key.localeCompare(b.key));
    return response({ ok: true, entities, serverTime: Date.now() });
  }

  const changes = Array.isArray(body?.changes) ? body.changes : [];
  if (changes.length > MAX_CHANGES) return response({ ok: false, error: `Too many changes; maximum is ${MAX_CHANGES}.` }, 400);

  let accepted = 0;
  for (const change of changes) {
    if (!isPlainObject(change)) continue;
    const entityKey = String(change.key ?? '');
    if (!entityKey || entityKey.length > 500) continue;
    const updatedAt = Number(change.updatedAt);
    if (!Number.isFinite(updatedAt) || updatedAt <= 0) continue;
    const deleted = !!change.deleted;
    const value = deleted ? null : change.value;
    const payload = { key: entityKey, updatedAt, deleted, value };
    const bytes = Buffer.byteLength(JSON.stringify(payload), 'utf8');
    if (bytes > MAX_ENTITY_BYTES) continue;

    const key = blobKey(spaceId(code), entityKey);
    const existing = await readEntity(st, key);
    if (existing && Number(existing.updatedAt) > updatedAt) continue;

    await st.set(key, JSON.stringify(payload), {
      metadata: { updatedAt: String(updatedAt), deleted: deleted ? '1' : '0' }
    });
    accepted += 1;
  }

  return response({ ok: true, accepted, serverTime: Date.now() });
}
